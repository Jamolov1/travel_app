package com.example.packages

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
